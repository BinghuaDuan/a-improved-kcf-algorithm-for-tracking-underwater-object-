function [positions, show_box] = improved_KCF(video_path,img_files,pos,tar_sz)
    padding = 4.5;  %��Ŀ�������չ
    lambda = 1e-4;  %regularization
    output_sigma_factor = 0.1;  %��˹�ֲ���ϵ��
    interp_factor = 0.02;   %����ģ��ʱ�����Բ�ֵ���ӣ�

    % ʹ�ø�˹��
    kernel.type='gaussian';
    kernel.sigma = 0.5;   

    %ʹ��HOG����
    features.hog = true;
    features.hog_orientations = 9;
    cell_size = 4;
    
    features.gray = false ;
    
    positions =  zeros(numel(img_files),2);
    rects = cell(numel(img_files),1);
    PSR_value = zeros(numel(img_files),1);
    
    
    window_sz = floor(tar_sz * (1 + padding));
  
    output_sigma = sqrt(prod(tar_sz)) * output_sigma_factor / cell_size;
    
    yf = fft2(gaussian_shaped_labels(output_sigma, floor(window_sz / cell_size)));
    cos_window = hann(size(yf,1)) * hann(size(yf,2))';
    
%     update_visualization = show_video(img_files, video_path);

    for frame = 1:numel(img_files) 
       
        im = imread([video_path img_files{frame}]);
        if size(im, 3) ~= 1
            im = rgb2gray(im);
        end
 

%������һ֡��ģ��model_xf��model_alphafԤ�Ȿ֡Ŀ���λ��
        if frame == 1
            PSR_iscoincident = 1;
        end
        if frame > 1
            patch = get_subwindow(im, pos, window_sz);
            feature = get_features(patch, features, cell_size, cos_window);
            zf = fft2(feature);
            kzf = gaussian_correlation(zf, model_xf, kernel.sigma);
            
            response = real(ifft2(model_alphaf .* kzf));
          
            [PSR, PSR_iscoincident] = PSR_judge(response, tar_sz);
            
            PSR_value(frame) = PSR;
            [vert_delta, horiz_delta] = find(response == max(response(:)),1);
            
            if vert_delta > size(zf,1) / 2
                vert_delta = vert_delta - size(zf,1);
            end
            if horiz_delta > size(zf,2) / 2
                horiz_delta = horiz_delta - size(zf,2);
            end
            
            pos = pos + cell_size * [vert_delta - 1, horiz_delta - 1];
            
            
        end
        %����Ԥ��Ŀ�����λ��posѵ����֡��
  
        %����԰��ֵ�ȴ�����ֵ����ģ�ͽ��и���
        if  PSR_iscoincident == 1
            patch = get_subwindow(im, pos, window_sz);
            feature = get_features(patch, features, cell_size, cos_window);
   

            xf = fft2(feature);
            kxf = gaussian_correlation(xf, xf, kernel.sigma);

            alphaf = yf ./ (kxf + lambda);
           
            if frame == 1
                model_xf = xf;
                model_alphaf = alphaf;
            else
                
                model_xf = (1 - interp_factor) * model_xf + interp_factor * xf;
                model_alphaf = (1 - interp_factor) * model_alphaf + interp_factor * alphaf;

            end
            
            
        end
        
        positions(frame, :) = pos;
        %pos ��tar_sz������[y,x]����ʽ�洢�ġ�
        box = [pos([2,1]) - tar_sz([2,1])/2, tar_sz([2,1])];
        rects{frame} = box;
        
%         update_visualization( frame,{box});
        
    end
    
    show_box = rects;

    
    

end