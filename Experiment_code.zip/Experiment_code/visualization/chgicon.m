function chgicon(h,filename)
%����matlab figure�����ϵ�matlab Ĭ��ͼ�ꡣ

if nargin < 2
    error('MATLAB:chgicon','%s','Too few input arguments');
end
if nargin > 2
    error('MATLAB:chgicon','%s','Too few input arguments');
end
newicon = javax.swing.ImageIcon(filename);
javaframe = get(h,'JavaFrame');
javaframe.setFigureIcon(newicon);


end