function [fig_handle, axes_handle, scroll_func] = ...
	videofig(num_frames, redraw_func, play_fps, big_scroll, ...
	key_func, varargin)
%==========================================================================
%Descripton:��Ҫʵ�ֲ�����Ƶʱ��һЩ��ݼ��Ĺ���
%           ���⣬����������һЩ�������£�
%           1����ʼ����Ƶ����ʱ��Ԫ�����ԣ���ЩԪ����Ҫ�У�
%               fig_handle--��ͼ��figure�ľ����
%               scroll_axes_handle--���������ڵ������᣻
%               scroll_handle--�������ϵ�patch�����
%               axes_handle--figure��ͼ����ʾ�������᣻
%           2��scroll����������frame����patch��λ�ã�������redraw������ʾͼ��͸��ٿ���
%
%==========================================================================
	%Ĭ�ϲ�������
	if nargin < 3 || isempty(play_fps), play_fps = 25; end  %play speed (frames per second)
	if nargin < 4 || isempty(big_scroll), big_scroll = 30; end  %page-up and page-down advance, in frames
	if nargin < 5, key_func = []; end
	
	%�������Ƿ�Ϸ�
	check_int_scalar(num_frames);
	check_callback(redraw_func);
	check_int_scalar(play_fps);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
	check_int_scalar(big_scroll);
	check_callback(key_func);

	click = 0;
	f = 1;  %��ʾ��ǰ֡��
    
    
%��ʼ����ʾͼ��Ĳ�����
%--------------------------------------------------------------------------
	%��ʼ��figure�������figure�ľ����
    %������Ըøı���ʾͼ��������С������С�ͷŴ�ͼ��
	fig_handle = figure('Color',[1 1 1],'Position',[100 100 750 500],'MenuBar','none', 'Units','norm', ...
		'WindowButtonDownFcn',@button_down, 'WindowButtonUpFcn',@button_up, ...
		'WindowButtonMotionFcn', @on_click, 'KeyPressFcn', @key_press, ...
		'Interruptible','off', 'BusyAction','cancel', varargin{:});
    icon = './sonar.jpg';
    chgicon(fig_handle, icon);
	
	%���������ڵ�������
	scroll_axes_handle = axes('Parent',fig_handle, 'Position',[0 0 1 0.03], ...
		'Visible','off', 'Units', 'normalized');
    
    
    %����figure��������x��y�ķ�Χ
	axis([0 1 0 1]); 
	axis off
	
	%����������
	scroll_bar_width = max(1 / num_frames, 0.01);
	scroll_handle = patch([0 1 1 0] * scroll_bar_width, [0 0 1 1], [0.5 0.5 0.5], ...
		'Parent',scroll_axes_handle, 'EdgeColor','none', 'ButtonDownFcn', @on_click); %patch����һ�������������,��ȡ�������ϵľ��ΰ�ťpatch�ľ����
	
	%������Ƶ�ļ�������
	play_timer = timer('TimerFcn',@play_timer_callback, 'ExecutionMode','fixedRate');
	
	
    %ͼ����ʾ������������axes_handle������򣩡�
	axes_handle = axes('Position',[0 0.03 1 0.97],'Visible','off','Parent',fig_handle);
    
	
	%���ع��������º�����
	
	scroll_func = @scroll;
    
%--------------------------------------------------------------------------

%========scroll������
%1�����¹�������patch��λ�ã�
%2������redraw�����ڻ����ͼ��͸��ٽ����������
    function scroll(new_f)
		if nargin == 1,  
			if new_f < 1 || new_f > num_frames,
				return
			end
			f = new_f;
		end
		
		%��֡��ת��Ϊ���������ʵ���x����
		scroll_x = (f - 1) / num_frames;
		
		%�ƶ�����������λ��
		set(scroll_handle, 'XData', scroll_x + [0 1 1 0] * scroll_bar_width);
		
		%������Ҫ����򲢵���redraw����
		set(fig_handle, 'CurrentAxes', axes_handle);
		redraw_func(f);
		
        
		pause(0.04)%���������ͣ0.04�룬��ʾ
    end
	

%========��ݼ��¼���������
	function key_press(src, event)  %#ok, unused arguments
		switch event.Key,  %process shortcut keys
		case 'leftarrow',
            
			scroll(f - 1);
		case 'rightarrow',
           
			scroll(f + 1);
		case 'pageup',
			if f - big_scroll < 1,  %scrolling before frame 1, stop at frame 1
				scroll(1);
			else
				scroll(f - big_scroll);
			end
		case 'pagedown',
			if f + big_scroll > num_frames,  %scrolling after last frame
				scroll(num_frames);
			else
				scroll(f + big_scroll);
			end
		case 'home',
			scroll(1);
		case 'end',
			scroll(num_frames);
		case 'return',
			play(1/play_fps)
		case 'backspace',
			play(5/play_fps)
		otherwise,
			if ~isempty(key_func),
				key_func(event.Key);  %#ok, call custom key handler
			end
		end
	end
	
%========����¼���������
	function button_down(src, event)  %#ok, unused arguments
		set(src,'Units','norm')
		click_pos = get(src, 'CurrentPoint');
		if click_pos(2) <= 0.03,  %only trigger if the scrollbar was clicked
			click = 1;
			on_click([],[]);
		end
	end

	function button_up(src, event)  %#ok, unused arguments
		click = 0;
	end

	function on_click(src, event)  %#ok, unused arguments
		if click == 0, return; end
		
		%get x-coordinate of click
		set(fig_handle, 'Units', 'normalized');
		click_point = get(fig_handle, 'CurrentPoint');
		set(fig_handle, 'Units', 'pixels');
		x = click_point(1);
		
		%get corresponding frame number
		new_f = floor(1 + x * num_frames);
		
		if new_f < 1 || new_f > num_frames, return; end  %outside valid range
		
		if new_f ~= f,  %don't redraw if the frame is the same (to prevent delays)
			scroll(new_f);
		end
	end
%========��Ƶ���ż�����
	function play(period)
		%toggle between stoping and starting the "play video" timer
        %��ֹͣ���ź�������������Ƶ����ʱ��֮���л�
		if strcmp(get(play_timer,'Running'), 'off'),
			set(play_timer, 'Period', period);
			start(play_timer);
		else
			stop(play_timer);
		end
    end

	function play_timer_callback(src, event)  %#ok
		%executed at each timer period, when playing the video
        %��ÿ����ʱ����������ִ��
		if f < num_frames,
			scroll(f + 1);
		elseif strcmp(get(play_timer,'Running'), 'on'),
			stop(play_timer);  %stop the timer if the end is reached
		end
	end

	
%========������麯��
	function check_int_scalar(a)
		assert(isnumeric(a) && isscalar(a) && isfinite(a) && a == round(a), ...
			[upper(inputname(1)) ' must be a scalar integer number.']);
    end

	function check_callback(a)
		assert(isempty(a) || strcmp(class(a), 'function_handle'), ...
			[upper(inputname(1)) ' must be a valid function handle.'])
	end
end

