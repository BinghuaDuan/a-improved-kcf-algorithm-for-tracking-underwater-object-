%-------------------------------------------------------------
%���ܣ�����ͬ�����㷨�ĸ��ٽ����ʾ��ͬһ֡ͼ����
%ʱ�䣺2018/5/16/10��33
%ע�⣺show_boxs����ʽΪ��{{}��{}��}
%-------------------------------------------------------------

function different_tracker_result()

   
      video_path = uigetdir();
     
      if video_path ~= 0
        video_path = strcat(video_path,'\');

        %����load_video_info(video_path)�õ�Ŀ�����ʵλ����Ϣground_truth
        [img_files, target_info, ground_truth] = load_video_info(video_path);

        first_frame = target_info{1};
        start_pos = first_frame.start_pos;
        tar_size = first_frame.tar_size;
        
        
        tar_select = {'1','2'};

        target_choice = listdlg('ListString',tar_select,'Name','��ѡ��Ŀ��');
        
        %��improved_KCF�㷨�У�padding��PSR_threshold��ֵ�ѱ��̶�
        padding = 1.5;
        PSR_threshold = 6;
        
        position_set = {};
        
        if isempty(target_choice) == 0
            s_pos = start_pos{target_choice};
            tar_size = tar_size{target_choice};
            pos = s_pos + floor(tar_size/2);
            tar_sz = tar_size;
            [meanshift_positions,meanshift_showbox] = meanshift(video_path,img_files,pos,tar_sz);
            [mosse_positions,mosse_showbox] = Mosse(video_path,img_files,pos,tar_sz);
            [csk_positions,csk_showbox] = csk(video_path,img_files,pos,tar_sz);
            [kcf_positions,kcf_showbox] = KCF(video_path,img_files,pos,tar_sz);
            [improvedkcf_positions,improvedkcf_showbox] = improved_KCF(video_path,img_files,pos,tar_sz);
            position_set{end + 1} = meanshift_positions;
            position_set{end + 1} = mosse_positions;
            position_set{end + 1} = csk_positions;
            position_set{end + 1} = kcf_positions;
            position_set{end + 1} = improvedkcf_positions;
         
            distance_plot(position_set,ground_truth,target_choice);
            

        else
            disp('δѡ��Ŀ��!!');
        end
        
        %�������㷨�ĸ��ٽ����ʾ��ͬһ֡ͼ���ϡ�
        
        update_visualization = show_video(img_files,video_path);
        for frame = 1:numel(img_files)
            frame_boxes={};
            frame_boxes{end + 1} = meanshift_showbox{frame};
            frame_boxes{end + 1} = mosse_showbox{frame};
            frame_boxes{end + 1} = csk_showbox{frame};
            frame_boxes{end + 1} = kcf_showbox{frame};
            frame_boxes{end + 1} = improvedkcf_showbox{frame};
            update_visualization(frame, frame_boxes);
        end
            
            
        
      else
          disp('δѡ����Ƶ�����ļ���');
      end
       


end

