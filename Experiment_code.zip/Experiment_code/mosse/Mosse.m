%--------------------------------------------------------------------------
%ʹ��MOsse�㷨�Ե���Ŀ����и���
%�޸�ʱ�䣺2018/5/8 15��30
%�޸����ݣ�������padding��window_sz,�����˱�����Ϣ��
function [positions,show_box] = Mosse(video_path,img_files,pos,tar_sz)
positions = zeros(numel(img_files),2);
show_box = cell(numel(img_files),1);

padding = 1.5;
window_sz = tar_sz *(1 + padding);
F_response = templateGauss(window_sz);
% update_visualization = show_video(img_files, video_path);
for frame = 1:numel(img_files)
    im = imread([video_path img_files{frame}]);
    
    if size(im,3) ~= 1
        im = rgb2gray(im);
    end
        
    if frame > 1
        sub_window = getsubbox(im,pos,window_sz);
        response=real(ifft2(F_Template.*fft2(sub_window)));
        [row_delta, col_delta] = find(response == max(response(:)), 1);
        pos = pos - floor(window_sz/2) + [row_delta, col_delta];  
         
    end
    
    F_im= fft2(getsubbox(im,pos,window_sz));
    F_Template=conj(F_im.*conj(F_response)./(F_im.*conj(F_im)+eps)); %mosseģ����� 
    
    positions(frame,:) = pos;
    
    box = [pos([2,1]) - tar_sz([2,1])/2,tar_sz([2,1])];
    show_box{frame} = box;
    
%     update_visualization(frame,{box});
    
    
    
end



end