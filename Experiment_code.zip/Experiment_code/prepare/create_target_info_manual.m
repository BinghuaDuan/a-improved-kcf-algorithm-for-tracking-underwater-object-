function target_info=create_target_info_manual(img_path)

gray_names=dir([img_path '*.bmp']);
img_file={gray_names.name};

target_info=cell(numel(img_file),1);

for frame=1:numel(img_file)
    img=imread([img_path img_file{frame}]);
    [num,pos,size]=get_rect(img);
    curtarget.tar_nums=num;
    curtarget.start_pos=pos;
    curtarget.tar_size=size;
    target_info{frame}=curtarget;
    
end


    function [num,pos,size]=get_rect(img)
        pos={};
        size={};
        fig=figure();
%         thresh=graythresh(img);
%         if thresh<0.1
%             thresh=0.2;
%         end
%         imbw=im2bw(img,thresh);
%         imbw=imfill(imbw,'holes');
%         se=[1,1,1;1,1,1;1,1,1];
%         imbw=imdilate(imbw,se);
%         imshow(imbw);
        imshow(img);
        rect=getrect(fig);
        target_count=1;
        while rect(3)~=0
            pos{target_count}=rect([2 1]);
            size{target_count}=rect([4 3]);
            rect=getrect(fig);
            target_count=target_count+1;
            
        end
        num=target_count-1;
       
    end




end