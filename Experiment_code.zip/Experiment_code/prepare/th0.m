function t = th0(X, l0, l1)

hist = imhist(X);
% hist = hist(2 : 256);
hist = hist(l0 + 1 : l1 + 1);
nums = sum(hist);
p = hist / nums;

E1=zeros(1,255);
E2=zeros(1,255); 
P=zeros(1,255);
E=zeros(1,255);

for t=1:1:l1 - l0 + 1
    for i=1:1:t
        P(t)=P(t)+p(i);
    end
    for i=1:1:t
        E1(t)=E1(t)-(p(i)/P(t))*log(p(i)/P(t)+eps);
    end
    
    for i=t+1:1:l1 - l0 + 1
        E2(t)=E2(t)-(p(i)/(1-P(t)))*log(p(i)/(1-P(t))+eps);
    end
    
    E(t)=E1(t)+E2(t);
end

t = find(E == max(E), 1);
t = t + l0;