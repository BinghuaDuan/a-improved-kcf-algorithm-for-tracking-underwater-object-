function colorimg_rebuild()
%description������α��ɫͼ��
clc;
clear ;
gray_imgpath='./dataimg/';
color_imgpath=strcat(gray_imgpath,'colorimg/');
grayimg=dir([gray_imgpath '*.bmp']);
img_files={grayimg.name};

for i=1:numel(img_files)
    gray_img=imread([gray_imgpath img_files{i}]);
    temporder=i;
    if temporder<10
        order=strcat('00',int2str(temporder));
    elseif temporder<100
        order=strcat('0',int2str(temporder));
    else
        order=int2str(temporder);
    end
    img_name=strcat(color_imgpath,order,'.bmp');
     %  ��ֵ�ָ�
     
%     t = th0(gray_img, 1, 255);  %��1 - 255֮�����ֵ
%     t0 = th0(gray_img, 1, t);  %��1 - t֮�����ֵ
%     t1 = th0(gray_img, t + 1, 255);  %��t - 255֮�����ֵ
%     
%     
%    %α��ɫ�任
%     color_img = pseudo(gray_img, t0, t, t1);


    color_img=pseudonew(gray_img);
    imwrite(color_img, img_name);
   
end
end
