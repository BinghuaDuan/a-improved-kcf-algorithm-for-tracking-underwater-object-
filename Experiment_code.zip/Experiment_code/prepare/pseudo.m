function result_img = pseudo(I, t0, t, t1)
%description��α��ɫ�任--�Ҷ�ӳ��ķ���
[m, n] = size(I);
% I=double(I);
R = zeros(m ,n);
G = zeros(m, n);
B = zeros(m, n);

for i = 1 : m
    for j = 1 : n
        if I(i, j) == 0
            continue;
        else if I(i, j) <= t0
                R(i, j) = 0;
                G(i, j) = 0;
                B(i, j) = t0/2;
            else if I(i, j) <= t
                    R(i, j) = 255 * (I(i, j) - t0) / (t - t0);
                    G(i, j) = 0;
                    B(i, j) = 255 * (t - I(i, j)) / (t - t0);
                else if I(i ,j) <= t1
                        R(i, j) = 255;
                        G(i, j) = 255 * (I(i, j) - t) / (t1 - t);
                        B(i, j) = 0;
                    else
                        R(i, j) = 255;
                        G(i, j) = 255;
                        B(i, j) = 0;
                    end
                end
            end
        end
    end
end


result_img(:, :, 1) = R(:, :);
result_img(:, :, 2) = G(:, :);
result_img(:, :, 3) = B(:, :);
% result_img=result_img/256;

% %����
%     % ��б��
%     t1 = (floor(n / 2) - floor(m * 0.707)) : floor((n) / 2); %����ʵ�������д
%     t2 = (m - floor(m * 0.707)) : m; %����ʵ�������д
%     [a, b] = size(t1);
%     for i = 1 : b
%         result_img(t2(i), t1(i), 1) = 255;
%         result_img(t2(i), t1(i), 2) = 0;
%         result_img(t2(i), t1(i), 3) = 0;
%     end
%     
%     t1 = (floor(n / 2)) : floor(m * 0.707 + n / 2);
%     t2 = m : -1 : (m - floor(m * 0.707));
%     [a, b] = size(t1);
%     for i = 1 : b
%         result_img(t2(i), t1(i), 1) = 255;
%         result_img(t2(i), t1(i), 2) = 0;
%         result_img(t2(i), t1(i), 3) = 0;
%     end
%     
%     %���Ⱦ���
%     for i = floor((n) / 2 - 50) : floor((n + 1) / 2 + 50)
%         result_img(floor(m * 3 / 4), i, 1) = 255;
%         result_img(floor(m * 2 / 4), i, 1) = 255;
%         result_img(floor(m * 1 / 4), i, 1) = 255;
%     end
%     % ������
%     for arf = -45 : 0.1 : 45%�е�̫�ܼ���
%         th = arf * pi / 180;
%         x = round(n / 2) + round(m * sin(th));
%         y = m - round(m * cos(th));
%         if x < 1
%             x = 1;
%         end
%         if y < 1
%             y = 1;
%         end
%         result_img(y, x, 1) = 255;
%         result_img(y, x, 2) = 0;
%         result_img(y, x, 3) = 0;
%     end
%     
%     th_f_22 = -22.5 * pi /180;
%     x_f_22 = round(n / 2) + round(m * sin(th_f_22));
%     y_f_22 = m - round(m * cos(th_f_22));
%     
%     th_22 = 22.5 * pi /180;
%     x_22 = round(n / 2) + round(m * sin(th_22));
%     y_22 = m - round(m * cos(th_22));
%     
%     
%     % ��ע����
%     ti = vision.TextInserter('-22.5', 'Location', [x_f_22 y_f_22], 'FontSize', 10, 'Color', [1 0 0]);
%     result_img = step(ti, result_img);%��ע-22.5��
%     ti = vision.TextInserter('22.5', 'Location', [x_22 y_22 + 10], 'FontSize', 10, 'Color', [1 0 0]);
%     result_img = step(ti, result_img);%��ע22.5��
%     ti = vision.TextInserter('0', 'Location', [375 5], 'FontSize', 10, 'Color', [1 0 0]);
%     result_img = step(ti, result_img);%��ע0��
%     
%     ti = vision.TextInserter('150m', 'Location', [365 120], 'FontSize', 10, 'Color', [1 0 0]);
%     result_img = step(ti, result_img);
%     ti = vision.TextInserter('100m', 'Location', [365 245], 'FontSize', 10, 'Color', [1 0 0]);
%     result_img = step(ti, result_img);
%     ti = vision.TextInserter('50m', 'Location', [365 370], 'FontSize', 10, 'Color', [1 0 0]);
%     result_img = step(ti, result_img);
%     ti = vision.TextInserter('-45', 'Location', [2 140], 'FontSize', 10, 'Color', [1 0 0]);
%     result_img = step(ti, result_img);
%     ti = vision.TextInserter('45', 'Location', [730 140], 'FontSize', 10, 'Color', [1 0 0]);
%     result_img = step(ti, result_img);
