% %ʹ�ó�������Զ���עĿ��
% target_info=create_target_info();
% save('target_info');


% �ֹ���עĿ��
img_path = uigetdir();
img_path = strcat(img_path,'\');
target_info_manual=create_target_info_manual(img_path);
mat_name = 'video.mat';
save([img_path mat_name],'target_info_manual');
% load([img_path mat_name]);


fidout = fopen([img_path 'ground_truth.txt'],'w+');
for i= 1:numel(target_info_manual)
    frame_struct= target_info_manual{i};
    frame_tar_nums = frame_struct.tar_nums;
    frame_start_pos = frame_struct.start_pos;
    frame_tar_size = frame_struct.tar_size;
    
    fprintf(fidout,'%d',frame_tar_nums);
    fprintf(fidout,'\r\n');
    
    for j = 1:frame_tar_nums
        line = [frame_start_pos{j} frame_tar_size{j}];
        fprintf(fidout,'%f ',line);
        fprintf(fidout,'\r\n');
    end
        
end
fclose(fidout);




