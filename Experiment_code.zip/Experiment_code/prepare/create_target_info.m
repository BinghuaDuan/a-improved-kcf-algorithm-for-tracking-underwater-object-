function target_info=create_target_info()
%------------------------------------------------------------------
%description:��ȡÿһ֡ͼ���е�Ŀ�����ϸ��Ϣ����ʹ�ýṹ��洢������
%             һ���ṹ���Ӧһ֡ͼ�����Ϣ��ÿ���ṹ���������Ϣ���£�
%            1��tar_nums����ǰ֡Ŀ���������
%            2��start_pos��Ŀ������ʼλ�ã���ʽΪ����㣨x,y����
%            3��tar_size��Ŀ���ĳߴ磬�����Ϳ�����ʽΪ����㣨x,y����
%example��   �ṹ�����յĸ�ʽ��
%           tar_nums��num
%           start_pos��<num*1>cell;
%           tar_size��<num*1>cell;
%-------------------------------------------------------------------
    img_path='./dataimg/';
    gray_img=dir([img_path '*.bmp']);
    img_files={gray_img.name};
    target_info=cell(numel(img_files),1);
    for frame=1:numel(img_files)
        im=imread([img_path img_files{frame}]);
        im=medfilt2(im);
        [num,sz,pos]=get_target(im);
        curtarget.tar_nums=num;
        curtarget.start_pos=pos;
        curtarget.tar_size=sz;
        target_info{frame}=curtarget;
        
    end
    
    
    
    
%--------------------------------------------------------------------------
    %��ȡÿһ֡�е�Ŀ��
    function [num,sz,pos]=get_target(im)
        
        sz={};
        pos={};
        %ʹ�������䷽���ͼ����зָ�
        thresh=graythresh(im);
        if thresh<0.1
            thresh=0.2;
        end
        imbw=im2bw(im,thresh);
        imbw=imfill(imbw,'holes');
        se=[1,1,1;1,1,1;1,1,1];
        imbw=imdilate(imbw,se);
        imshow(imbw)
%         imbw2=bwperim(imbw);
        [m,n]=size(imbw);


        %���������������ķ�����Ŀ��
        num=0;
        for i=1:m
            for j=1:n
                if imbw(i,j)==1
                    seed=[i,j];
                    top=1;
                    stack=[seed(1),seed(2)];
%                     flagim=zeros(m,n);
%                     flagim(seed(1),seed(2))=1;
                    
                
                    
                      count=0;
                      targetset={};
                       while top~=0
                            r=stack(1,1);
                            c=stack(1,2);
                            
                            for x=-1:1
                                for y=-1:1
                                    if r+x>0 & r+x<=m & c+y>0 & c+y<=n
                                        if imbw(r+x,c+y)==1
                                            top=top+1;
                                            stack(top,:)=[r+x,c+y];
                                            count=count+1;
                                            targetset{count}=[r+x,c+y];
%                                             disp('targetset_num=');
%                                             numel(targetset)
%                                                 flagim(r+x,c+y)=1;
                                            
                                            imbw(r+x,c+y)=0; 
                                        end
                                    end

                                end
                            end
               

                            stack=stack(2:top,:);
                            top=top-1;

                        end        %end while

                        %��targetset�е����ظ�������200ʱ��ѡ������Ϊһ��Ŀ��
%                         count
                        if count>=300
                            pointx=zeros(count,1);
                            pointy=pointx;
                            for k=1:count
                                point=targetset{k};
                                pointx(k)=point(1);
                                pointy(k)=point(2);
                            end
                            minrow=min(pointx);
                            maxrow=max(pointx);
                            
                            mincol=min(pointy);
                            maxcol=max(pointy);
                            
%                             disp('minrow=');
%                             minrow
%                             disp('maxrow=');
%                             maxrow
%                             disp('mincol=');
%                             mincol
%                             disp('maxcol=');
%                             maxcol
                            p=[minrow mincol];
                            tar_sz=[maxrow-minrow maxcol-mincol];
                            num=num+1;
                            sz{num}=tar_sz;
                            pos{num}=p;
                            

                        end
                     
                end       %end if 
                      
        
            end
         
        end
    end
%--------------------------------------------------------------------------
    
   end