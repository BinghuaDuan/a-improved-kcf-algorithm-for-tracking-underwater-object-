function img_resize()
clc;
clear ;
% gray_imgpath='./dataimg/img/';
gray_imgpath='D:\Study\DATA\D1_unresized_img\D1\';
grayimg=dir([gray_imgpath '*.bmp']);
% resize_imgpath='./Original_dataimg/resized_img/D1/';
resize_imgpath='C:\Users\20546\Desktop\img\D1\';
img_files={grayimg.name};

%%������D1���ļ�������
% for i = 1:numel(img_files)
%     old_name = strcat(gray_imgpath,img_files{i});
%     no = strfind(img_files{i},'.');
%     nostr = img_files{i}(1:no - 1);
%     nonum = str2num(nostr);
%     if nonum < 1000
%         new_name = strcat('0',img_files{i});
%         command = ['rename' 32 old_name 32 new_name];
%         status  = dos(command);
%         if status  == 0
%             disp('�����ɹ�');
%         else
%             disp('������ʧ��');
%         end
%     end
% end
        

for i=1:numel(img_files)
% for i=1:350
    gray_img=imread([gray_imgpath img_files{i}]);
    temporder=i;
    if temporder<10
        order=strcat('000',int2str(temporder));
    else if temporder<100
            order=strcat('00',int2str(temporder));
        else if temporder < 1000
            order=strcat('0',int2str(temporder));
            else
            order = int2str(temporder);
            end
        end
        
    end
    img_name=strcat(resize_imgpath,order,'.bmp');
 
    resize_img=imresize(gray_img,[800,1200]);
    imwrite(resize_img, img_name);
end

end
