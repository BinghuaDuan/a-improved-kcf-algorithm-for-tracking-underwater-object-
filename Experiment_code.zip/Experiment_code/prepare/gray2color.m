function gray2color()
%���Ҷ�ͼ����α��ɫͼ��
    directory  = uigetdir();

    directory = strcat(directory,'\');
%     filenames = dir(directory);
%     imgfile = {};
%     for i = 1: numel(filenames)
%         if filenames(i).isdir == 0
%             imgfile{end +1} = filenames(i).name;
%         end
%     end
%     sort(imgfile);
    filenames = dir([directory '*.bmp']);
    imgfile = {filenames.name};
    if ~exist([directory 'color_img'])
        mkdir(directory,'color_img');
    end
    
    for j = 1:numel(imgfile)
        gray_img = imread([directory imgfile{j}]);
        color_img = pseudonew(gray_img);
%         ��ֵ�ָ�
%         t = th0(gray_img, 1, 255);  %��1 - 255֮�����ֵ
%         t0 = th0(gray_img, 1, t);  %��1 - t֮�����ֵ
%         t1 = th0(gray_img, t + 1, 255);  %��t - 255֮�����ֵ
% 
%         α��ɫ�任
%         color_img = pseudo(gray_img, t0, t, t1);

        if j<10
            img_path = strcat(directory,'color_img\','000',int2str(j),'.bmp');
        
        else if j<100
            img_path = strcat(directory,'color_img\','00',int2str(j),'.bmp');
        
            else j < 1000
            img_path = strcat(directory,'color_img\','0',int2str(j),'.bmp');
            end
        end
        
        imwrite(color_img,img_path);
    end
        
            
    


end