function filter_img()

    directory  = uigetdir();

    directory = strcat(directory,'\');
    filenames = dir(directory);
    imgfile = {};
    for i = 1: numel(filenames)
        if filenames(i).isdir == 0
            imgfile{end +1} = filenames(i).name;
        end
    end
    sort(imgfile);
    if ~exist([directory 'filt_img'])
        mkdir(directory,'filt_img');
    end
    
    for j = 1:numel(imgfile)
        gray_img = imread([directory imgfile{j}]);
        filt_img = medfilt2(gray_img);

        if j<10
            img_path = strcat(directory,'filt_img\','000',int2str(j),'.bmp');
        
        else if j<100
            img_path = strcat(directory,'filt_img\','00',int2str(j),'.bmp');
        
            else j < 1000
            img_path = strcat(directory,'filt_img\','0',int2str(j),'.bmp');
            end
        end
        
        imwrite(filt_img,img_path);
    end
        
            
    



end