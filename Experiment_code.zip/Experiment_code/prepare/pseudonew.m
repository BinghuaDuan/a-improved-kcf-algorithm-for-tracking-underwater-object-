function color_img=pseudonew(I)

%  [m,n]=size(I);
%  color_img=zeros(m,n,3);
%  for x=1:m
%      for y=1:n
%             gray=I(x,y);
%             if gray== 0
%             continue;
%             end
%             if gray<255/4
%                      color_img(x,y,2)=4*gray;
%                      color_img(x,y,3)=255;
%                 else if gray<=255/2
%                      color_img(x,y,2)=255;
%                      color_img(x,y,3)=-4*gray+510;
%                     else if gray<=255*3/4
%                      color_img(x,y,1)=4*gray-2*255;
%                      color_img(x,y,2)=255;
%                         else
%                      color_img(x,y,1)=255;
%                      color_img(x,y,2)=-4*gray+4*255;
%                         end
%                     end
%             end
%      end
%  end
    I = medfilt2(I);
    I=double(I);
    
    [m,n]=size(I);
    R=zeros(m,n);
    G=R;
    B=G;
    L=256;
    for i=1:m
        for j=1:n
            if I(i,j)==0
                continue;
            end
            if I(i,j)<=L/4
                R(i,j)=0;
                %�Ҷȱ任ԭʼϵ��
%                 G(i,j)=4*I(i,j);
                G(i,j)=2*I(i,j);
                B(i,j)=L/2;
            else if I(i,j)<=L/2
                    R(i,j)=0;
                    G(i,j)=L;
                    B(i,j)=-4*I(i,j)+2*L;
                else if I(i,j)<=3*L/4
                        R(i,j)=4*I(i,j)-2*L;
                        G(i,j)=L;
                        B(i,j)=0;
                    else
                        R(i,j)=L;
                        G(i,j)=-4*I(i,j)+4*L;
                        B(i,j)=0;
                    end
                end
            end
        end
    end
    rgbim=zeros(m,n,3);
    for i=1:m
        for j=1:n
            rgbim(i,j,1)=R(i,j);
            rgbim(i,j,2)=G(i,j);
            rgbim(i,j,3)=B(i,j);
        end
    end
    
    color_img=rgbim/256;
              
end
