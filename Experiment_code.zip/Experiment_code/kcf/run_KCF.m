function run_KCF()

      video_path = uigetdir();
      
      if video_path ~= 0
        video_path = strcat(video_path,'\');

        %����load_video_info(video_path)�õ�Ŀ�����ʵλ����Ϣground_truth
        [img_files, target_info, ground_truth] = load_video_info(video_path);

        first_frame = target_info{1};

        start_pos = first_frame.start_pos;
        tar_size = first_frame.tar_size;

        tar_select = {'1','2'};

        load('line_count.mat');

        choice = listdlg('ListString',tar_select,'Name','��ѡ��Ŀ��');

        if isempty(choice) == 0
            s_pos = start_pos{choice};
            tar_size = tar_size{choice};
            pos = s_pos + floor(tar_size/2);
            tar_sz = tar_size;
            [positions,show_box] = KCF(video_path,img_files,pos,tar_sz);
            
            precision_plot_overlap(positions, ground_truth, choice,tar_sz,line_count,strcat('padding=','2.5'));
        else
            disp('δѡ��Ŀ��!!');
        end
        
        line_count = line_count + 1;
        save('line_count.mat','line_count');
      else
          disp('δѡ����Ƶ�����ļ���');
      end

end