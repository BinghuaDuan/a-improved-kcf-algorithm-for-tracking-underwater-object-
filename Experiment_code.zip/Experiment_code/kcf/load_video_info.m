function [img_files,target_info, ground_truth] = load_video_info(video_path)
%LOAD_VIDEO_INFO
%   Loads all the relevant information for the video in the given path:
%   the list of image files (cell array of strings), initial position
%   (1x2), target size (1x2), the ground truth information for precision
%   calculations (Nx2, for N frames), and the path where the images are
%   located. The ordering of coordinates and sizes is always [y, x].
%   �����˳������[y,x]����ʽ��
%   ��ȡ�ļ����µ�ͼ���ļ����ƣ�ÿһ֡���Ŀ�����Ϣ������pos��size��groundtruth=pos+size/2��
%   grounftruth ���������ȼ���ġ�

%     filename=[base_path 'groundtruth.txt'];
%     f=fopen(filename);
%     ground_truth = textscan(f, '%f %f %f %f');
%     ground_truth = cat(2, ground_truth{:});
% 	fclose(f);
%     
%     %set initial position and size
% 	target_sz = [ground_truth(1,4), ground_truth(1,3)];
% 	pos = [ground_truth(1,2), ground_truth(1,1)] + floor(target_sz/2);
%     
%     if size(ground_truth,1) == 1,
% 		%we have ground truth for the first frame only (initial position)
% 		ground_truth = [];
% 	else
% 		%store positions instead of boxes
% 		ground_truth = ground_truth(:,[2,1]) + ground_truth(:,[4,3]) / 2;
%     end
%     
%     video_path = [base_path 'img/'];
%     
%     img_files = dir([video_path '*.jpg']);
%     %{img_files.name}����cell����
%     img_files = sort({img_files.name});
% 	assert(~isempty(img_files), 'No image files to load.')

%----------------------------------------------------------
%function��1�����صõ�ÿһ֡ͼ���ж��Ŀ�����Ϣtarget_info��
%          2���õ�����ͼƬ��������Ϣimg_files��
%          3������target_info ����ÿһ֡ͼ���ж��ͼ���ground_truth(ground_truth=pos([2 1])+size([2 1])/2)

%��video.mat�ļ��л�ȡground_truth��target_info_manual����Ϣ
%     load([video_path 'video.mat']);
%     img_files=dir([video_path '*.bmp']);
%     img_files=sort({img_files.name});
%     assert(~isempty(img_files),'No image files to load');
%     target_info=target_info_manual;
%     ground_truth=cell(numel(img_files),1);
%     for frame=1:numel(img_files)
%         target_nums=target_info_manual{frame}.tar_nums;
%         target_pos=target_info_manual{frame}.start_pos;
%         target_size=target_info_manual{frame}.tar_size;
%         target_truth=cell(numel(target_nums),1);
%         for i=1:target_nums
%             pos=target_pos{i};
%             sz=target_size{i};
%             target_truth{i}=pos+floor(sz/ 2);
%         end
%         
%         ground_truth{frame}=target_truth;
%         
%     end
%     
    
    %��ground_truth.txt�ļ��л�ȡtarget_info��ground_truth.
    %target_info �д洢���ǽṹ�壬ground_truth�д洢����
    img_files = dir([video_path '*.bmp']);
    img_files=sort({img_files.name});
%     assert(~isempty(img_files),'No image files to load');
    if isempty(img_files)
        disp('No image files to load');
    end
    
    target_info = cell(numel(img_files),1);
    ground_truth = cell(numel(img_files),1);
    
    start_pos = {};
    tar_sz = {};
    target_truth = {};
    tar_nums = 0;
    fidin = fopen([video_path 'ground_truth.txt'],'r');
    t = 0;
    frame = 1;
    if fidin ~= -1
        while ~feof(fidin)
            tline = fgetl(fidin);
            t = t + 1; 
            tline = str2num(tline);
            %һ��һ�ж�ȡground_truth �е����ݣ�����һ���ǵ���һ������n��ʱ��
            %��ʾ�����n���ǹ���n��Ŀ���start_pos ��tar_size;
            %ground_truth �ĸ�ʽ��{{[x,y],[x,y]},...{[x,y],[x,y]}}
            if numel(tline) == 1
                if t ~= 1
                target.tar_nums = tar_nums;
                target.start_pos = start_pos;
                target.tar_size  = tar_sz;
                target_info{frame} = target;
                ground_truth{frame} = target_truth;
                frame = frame + 1;
                start_pos = {};
                tar_sz = {};
                target_truth = {};
                end
                tar_nums = tline;

            else
                start_pos{end + 1} = tline(1:2);
                tar_sz{end + 1} = tline(3:4);
                target_truth{end + 1} = tline(1:2) + floor(tline(3:4) /2);
            end

        end
        target.tar_nums = tar_nums;
        target.start_pos = start_pos;
        target.tar_size  = tar_sz;
        target_info{frame} = target;
        ground_truth{frame} = target_truth;

        fclose(fidin);
    else
        errordlg('ground_truth.txt�ļ������ڣ�','����');
    end
    
end