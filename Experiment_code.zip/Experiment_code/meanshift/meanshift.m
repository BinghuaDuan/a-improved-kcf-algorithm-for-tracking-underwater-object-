function [positions, show_box] = meanshift(video_path, img_files, pos ,tar_sz)

    positions = zeros(numel(img_files,2),2);
    show_box = cell(numel(img_files),1);
    
    window_sz = floor(tar_sz);
    new_pos = pos ;
    
    positions(1,:) = new_pos;
    show_box{1} = [new_pos([2,1]) - tar_sz([2,1])/2,tar_sz([2,1])];
    
    first_frame = imread([video_path img_files{1}]);
    patch = get_subwindow(first_frame,new_pos,window_sz);

    y_sz= size(patch,2);
    x_sz = size(patch,1);

    %����h^2
    h = (y_sz/2) ^2 + (x_sz/2) ^2;

    %Ȩֵ����
    weight = zeros(x_sz ,y_sz);

    for i = 1:x_sz
        for j = 1:y_sz
            dist = (i - x_sz /2)^2 + (j - y_sz /2)^2;
            weight(i,j) = 1 - dist /h;
        end
    end

     %��һ��ϵ��
    C = 1/sum(weight(:));
%     hist_target = zeros(1,256);
    hist_target = zeros(1,4096);
        for i = 1:x_sz
            for j = 1:y_sz
    %             first_index = floor(patch(i,j)/16);
%                 index = patch(i,j);
                p_r=floor(double(patch(i,j,1))/16);  
                p_g=floor(double(patch(i,j,2))/16);  
                p_b=floor(double(patch(i,j,3))/16);  
                index =p_r*256+p_g*16+p_b;  
                hist_target(index + 1 ) = hist_target(index + 1) + weight(i,j);
            end
        end

     hist_target = hist_target * C;
     
     for frame = 2:numel(img_files)
         
        im = imread([video_path img_files{frame}]);
        iteration = 0;
        shift = [2,2];
        %�����ѡ����Ȩֱֵ��ͼ
        while((shift(1)^2 + shift(2)^2) > 0.5 && iteration < 20)
            
            patch = get_subwindow(im,new_pos, window_sz);
            iteration = iteration + 1;
%               hist_candidate = zeros(1,16);

            y_sz= size(patch,2);
            x_sz = size(patch,1);
%             hist_candidate = zeros(1,256);
            hist_candidate = zeros(1,4096);
            
            index  = zeros(x_sz,y_sz);
            for i = 1:x_sz
                for j = 1:y_sz
%                     index(i,j) = floor(patch(i,j) / 16);
%                     index(i,j) = patch(i,j);
                    q_r=floor(double(patch(i,j,1))/16);  
                    q_g=floor(double(patch(i,j,2))/16);  
                    q_b=floor(double(patch(i,j,3))/16);  
                    index(i,j)=q_r*256+q_g*16+q_b;  
      
                    hist_candidate(index(i,j) + 1) = hist_candidate(index(i,j) + 1) + weight(i,j);
                end
            end

            hist_candidate = hist_candidate * C;
         %����Ư�������ļ��㹫ʽ��ϵ��
%               w = zeros(1,16);
%               for i = 1:16
%             w = zeros(1,256);

            w = zeros(1,4096);
            for i = 1:4096
                if hist_candidate(i) ~= 0
                    w(i) = sqrt(hist_target(i)/hist_candidate(i));
                else
                    w(i) = 0;
                end
            end

        %����Ư������
            w_sum = 0;
            xw = [0,0];
            for i = 1:x_sz
                for j = 1:y_sz
                    w_sum = w_sum + w(index(i,j) + 1);
                    xw = xw + w(index(i,j) + 1) * [(i - x_sz/2 ),(j - y_sz/2 )];
                end
            end

            shift = floor(xw / w_sum);
            new_pos = new_pos + shift;
            
        end
        
        positions(frame,:) = new_pos;
        show_box{frame} = [new_pos([2,1]) - floor(tar_sz([2,1])/2),tar_sz([2,1])];
        
        
        
     end


end