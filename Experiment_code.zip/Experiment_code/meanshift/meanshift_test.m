%------------------------------------------------------------------
%Description:��ֵƯ���㷨ʵ�ֵ�Ŀ����١�
%  
function [positions,show_box]=meanshift_test(video_path, img_files,pos,tar_sz)


    positions = zeros(numel(img_files),2);
    show_box = cell(numel(img_files),1);
    
    padding = 1.5;
    window_sz = floor(tar_sz * (padding + 1));
    new_pos = pos ;
    
     positions(1,:) = new_pos;
     show_box{1} = [new_pos([2,1]) - tar_sz([2,1])/2,tar_sz([2,1])];
    
    im = imread([video_path img_files{1}]);
    patch = get_subwindow(im,new_pos,window_sz);

    y_sz= size(patch,2);
    x_sz = size(patch,1);

    %����h^2
    h = (y_sz/2) ^2 + (x_sz/2) ^2;

    %Ȩֵ����
    weight = zeros(x_sz ,y_sz);

    for i = 1:x_sz
        for j = 1:y_sz
            dist = (i - x_sz /2)^2 + (j - y_sz /2)^2;
            weight(i,j) = 1 - dist /h;
        end
    end

     %��һ��ϵ��
    C = 1/sum(weight(:));
    hist_target = zeros(1,255);
        for i = 1:x_sz
            for j = 1:y_sz
    %             first_index = floor(patch(i,j)/16);
                index = patch(i,j);
                if index < 1
                    index = index + 1;
                end
                hist_target(index ) = hist_target(index) + weight(i,j);
            end
        end

     hist_target = hist_target * C;
    
    for frame = 2:numel(img_files)
        %ʹ����һ֡Ŀ��Ȩֵ��ֱ��ͼ��ͨ����ֵƯ�Ƶõ���ǰ֡Ŀ���Ԥ��λ��result_pos��
        % new_pos��hist_target��C��weight������һ֡�Ĳ�����C��weight�ǳ���
        im = imread([video_path img_files{frame}]);
        result_pos = meanshift(im, new_pos, window_sz,hist_target, C, weight);
        
        result_pos
        %���㵱ǰ֡Ŀ��Ȩֵ��ֱ��ͼ
        %������meanshift�õ��ĵ�ǰ֡��Ŀ����λ��result_pos�����㵱ǰ֡�Ĳ���hist_target
        new_pos = result_pos;
        positions(frame,:) = new_pos;
        show_box{frame} = [new_pos([2,1]) - tar_sz([2,1])/2,tar_sz([2,1])];
        
        patch = get_subwindow(im,new_pos,window_sz);
        
        %����Ŀ���Ȩֱֵ��ͼ

    %     hist_target = zeros(1,16);
        hist_target = zeros(1,255);
        for i = 1:x_sz
            for j = 1:y_sz
    %             first_index = floor(patch(i,j)/16);
                index = patch(i,j);
                if index < 1
                    index = index + 1;
                end
                hist_target(index ) = hist_target(index) + weight(i,j);
            end
        end

        hist_target = hist_target * C;
        
                  
    end
   
    
end

function newpos = meanshift(im,pos, window_sz, hist_target, C, weight)

        newpos = pos;
        
        iteration = 0;
        shift = [6,6];
        %�����ѡ����Ȩֱֵ��ͼ
        while((shift(1)^2 + shift(2)^2) >0.5 && iteration < 30)
%             disp('newpos---meanshift');
%             newpos
            patch = get_subwindow(im,newpos, window_sz);
            iteration = iteration + 1;
%               hist_candidate = zeros(1,16);

            y_sz= size(patch,2);
            x_sz = size(patch,1);
            hist_candidate = zeros(1,255);
            
            index  = zeros(x_sz,y_sz);
            for i = 1:x_sz
                for j = 1:y_sz
%                     index(i,j) = floor(patch(i,j) / 16);
                    index(i,j) = patch(i,j);
                    if index(i,j) < 1
                        index(i,j) = 1;
                    end
                    hist_candidate(index(i,j) ) = hist_candidate(index(i,j)) + weight(i,j);
                end
            end

            hist_candidate = hist_candidate * C;
         %����Ư�������ļ��㹫ʽ��ϵ��
%               w = zeros(1,16);
%               for i = 1:16
                w = zeros(1,255);
            for i = 1:255
                if hist_candidate(i) ~= 0
                    w(i) = sqrt(hist_target(i)/hist_candidate(i));
                else
                    w(i) = 0;
                end
            end

        %����Ư������
            w_sum = 0;
            xw = [0,0];
            for i = 1:x_sz
                for j = 1:y_sz
                    w_sum = w_sum + w(index(i,j));
                    xw = xw + w(index(i,j)) * [(i - x_sz/2 ),(j - y_sz/2 )];
                end
            end

            shift = floor(xw / w_sum);
            newpos = newpos + shift([2,1]);
        end
        
        
        
    
        
            
            
              
            
end
    
    





