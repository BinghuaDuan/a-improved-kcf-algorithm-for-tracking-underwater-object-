function [positions,show_box] = meanshift_new(video_path ,img_files, pos, tar_sz)

    positions = zeros(numel(img_files),2);
    show_box = cell(numel(img_files),1);
    %Ŀ���size�����У�
  
    im = imread([video_path img_files{1}]);
    a = floor(tar_sz(1));
    b = floor(tar_sz(2));
    temp = get_subwindow(im,pos,tar_sz);
    rect = [pos([2,1]) - floor(tar_sz([2,1])/2),tar_sz([2,1])];
%     disp('rect=');
%     rect
    positions(1,:)= pos;
    show_box{1} = rect;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%����Ŀ��ͼ���Ȩֵ����%%%%%%%%%%%%%%%%%%%%%%%  
    y(1)=a/2;  
    y(2)=b/2;  
   
    m_wei=zeros(a,b);%Ȩֵ����  
    h=y(1)^2+y(2)^2 ;%����  


    for i=1:a  
        for j=1:b  
            dist=(i-y(1))^2+(j-y(2))^2;  
            m_wei(i,j)=1-dist/h; %epanechnikov profile  
        end  
    end  
    C=1/sum(sum(m_wei));%��һ��ϵ��  


    %����Ŀ��Ȩֱֵ��ͼqu  
    %hist1=C*wei_hist(temp,m_wei,a,b);%target model  
    hist1=zeros(1,4096);  
    % hist1=zeros(1,256);  
    for i=1:a  
        for j=1:b  
            %rgb��ɫ�ռ�����Ϊ16*16*16 bins  
            q_r=floor(double(temp(i,j,1))/16);  %fixΪ����0ȡ������  
            q_g=floor(double(temp(i,j,2))/16);  
            q_b=floor(double(temp(i,j,3))/16);  
            q_temp=q_r*256+q_g*16+q_b;            %����ÿ�����ص��ɫ����ɫ����ɫ������ռ����  
    %           q_temp = temp(i,j);
            hist1(q_temp+1)= hist1(q_temp+1)+m_wei(i,j);    %����ֱ��ͼͳ����ÿ�����ص�ռ��Ȩ��  
        end  
    end  
    hist1=hist1*C;  
    rect(3)=ceil(rect(3));  
    rect(4)=ceil(rect(4));  


    %%%%%%%%%%%%%%%%%%%%%%%%%��ȡ����ͼ��  
  
    for l=2:numel(img_files)
        Im=imread([video_path img_files{l}]);  
        num=0;  
        Y=[2,2];  

        %%%%%%%mean shift����  
        while((Y(1)^2+Y(2)^2>0.5)&&num<20)   %��������  
            num=num+1;  
 
            %�����ѡ����ֱ��ͼ  
            %hist2=C*wei_hist(temp1,m_wei,a,b);%target candidates pu  
            hist2=zeros(1,4096);  
    %         hist2=zeros(1,256); 
            temp1 = get_subwindow(Im,pos,tar_sz);
            for i=1:a  
                for j=1:b  
                    q_r=floor(double(temp1(i,j,1))/16);  
                    q_g=floor(double(temp1(i,j,2))/16);  
                    q_b=floor(double(temp1(i,j,3))/16);  
                    q_temp1(i,j)=q_r*256+q_g*16+q_b;  
    %                   q_temp1(i,j)= temp1(i,j);
                    hist2(q_temp1(i,j)+1)= hist2(q_temp1(i,j)+1)+m_wei(i,j);  
                end  
            end  
            hist2=hist2*C;  
 

            w=zeros(1,4096);  
    %         w=zeros(1,256);  
            for i=1:4096
                if(hist2(i)~=0) %������  
                    w(i)=sqrt(hist1(i)/hist2(i));  
                else  
                    w(i)=0;  
                end  
            end  

            %������ʼ��  
            sum_w=0;  
            xw=[0,0];  
            for i=1:a;  
                for j=1:b  
                    sum_w=sum_w+w(uint32(q_temp1(i,j))+1);  
                    xw=xw+w(uint32(q_temp1(i,j))+1)*[i-y(1)-0.5,j-y(2)-0.5];  
                end  
            end  
            Y=xw/sum_w;  
            %���ĵ�λ�ø���  
            pos = pos + Y;
            rect(1)=rect(1)+Y(2);  
            rect(2)=rect(2)+Y(1);  
            
           
        end  
         positions(l,:) = pos ;
         show_box{l} = rect;
        
        
    end

      

    
        
      

      
end  
