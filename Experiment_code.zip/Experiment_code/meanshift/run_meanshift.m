function run_meanshift()
directory = uigetdir();
video_path = strcat(directory,'\');
files = dir(strcat(video_path,'*.bmp'));
img_files = {files.name};
sort(img_files);
I=imread(strcat(video_path,'001.bmp'));  
fig = figure(1);
imshow(I);
% rect = getrect(fig);
[temp,rect] = imcrop(I);
pos =  rect([1,2]) + floor(rect([3,4])/2);
tar_sz = rect([3,4]);
rect_h = cell(numel(img_files),1);
[positions,show_box] = meanshift(video_path,img_files,pos,tar_sz);
im_h =[];
axe_h = axes();
for i = 1:numel(img_files)
    im = imread([video_path img_files{i}]);
    
    if isempty(im_h)
        im_h = imshow(im,'Parent',axe_h);
    else
        set(im_h,'CData',im);
    end
    pause(0.1);
    
    if i>= 2
        for j = 1:i-1
            set(rect_h{j},'visible','off');
        end
    end
    rect_h{i} = rectangle('Position',show_box{i},'Parent',axe_h,'EdgeColor','r');
end
    



