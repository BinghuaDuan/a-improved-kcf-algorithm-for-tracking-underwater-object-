function different_precision()

video_path = uigetdir();
     
      if video_path ~= 0
        video_path = strcat(video_path,'\');

        %����load_video_info(video_path)�õ�Ŀ�����ʵλ����Ϣground_truth
        [img_files, target_info, ground_truth] = load_video_info(video_path);

        first_frame = target_info{1};
        
        tar_size = first_frame.tar_size;
        target_choice = 2;
        target_sz = tar_size{target_choice};
        
        precision_set = {};
        precision_overlap_set = {};
       
        
        [tarone_positions, IKCF_positions,time] = multi_tracker(video_path, img_files, target_info, 'improved_KCF');
        IKCF_precision = precision_calculate(IKCF_positions,ground_truth,2);
        IKCF_precision_overlap = precision_caculate_overlap(IKCF_positions,ground_truth,2,target_sz);
        precision_set{end+1} = IKCF_precision;
        precision_overlap_set{end+1}  = IKCF_precision_overlap;
        
        [tarone_positions, KCF_positions,time] = multi_tracker(video_path, img_files, target_info, 'KCF');
        KCF_precision = precision_calculate(KCF_positions,ground_truth,2);
        KCF_precision_overlap = precision_caculate_overlap(KCF_positions,ground_truth,2,target_sz);
        precision_set{end+1} = KCF_precision;
        precision_overlap_set{end+1}  = KCF_precision_overlap;
        
        [tarone_positions, CSK_positions,time] = multi_tracker(video_path, img_files, target_info, 'CSK');
        CSK_precision = precision_calculate(CSK_positions,ground_truth,2);
        CSK_precision_overlap = precision_caculate_overlap(CSK_positions,ground_truth,2,target_sz);
        precision_set{end+1} = CSK_precision;
        precision_overlap_set{end+1}  = CSK_precision_overlap;
        
        [tarone_positions, MOSSE_positions,time] = multi_tracker(video_path, img_files, target_info, 'Mosse');
        MOSSE_precision = precision_calculate(MOSSE_positions,ground_truth,2);
        MOSSE_precision_overlap = precision_caculate_overlap(MOSSE_positions,ground_truth,2,target_sz);
        precision_set{end+1} = MOSSE_precision;
        precision_overlap_set{end+1}  = MOSSE_precision_overlap;
        
        [tarone_positions, MEANSHIFT_positions,time] = multi_tracker(video_path, img_files, target_info, 'Meanshift');
        MEANSHIFT_precision = precision_calculate(MEANSHIFT_positions,ground_truth,2);
        MEANSHIFT_precision_overlap = precision_caculate_overlap(MEANSHIFT_positions,ground_truth,2,target_sz);
        precision_set{end+1} = MEANSHIFT_precision;
        precision_overlap_set{end+1}  = MEANSHIFT_precision_overlap;
        
        
        different_precision_plot(precision_set,1)
        different_precision_plot(precision_overlap_set,2)
        
        
        
        
        
        
      else
          disp('δѡ����Ƶ�����ļ���');
      end
        
        

end