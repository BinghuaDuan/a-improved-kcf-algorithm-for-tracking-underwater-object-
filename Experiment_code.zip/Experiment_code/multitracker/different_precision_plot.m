function different_precision_plot(precision_set, type)
color_list = {'r','g','b','y','k','c','m'};

marker_list = {'o','v','x','s','d'};

if type == 1 
    
    f1 = figure(7);
    axes_precision = axes(f1);
     threshold = (1:30);
    for k = 1:numel(precision_set)
        precision = precision_set{k};
        line(axes_precision,threshold,precision,'color',color_list{k},'LineStyle','-','LineWidth',2,'marker',marker_list{k});
        xlabel('����λ�������ֵ');
        ylabel('֡��/��֡��');
        hold on;
    end
    legend('IKCF','KCF','CSK','MOSSE','MEANSHIFT','Location','northwest');
else
    f2 = figure(8);
    axes_precision_overlap = axes(f2);
    threshold_overlap = (0.02:0.02:1);
    for k = 1:numel(precision_set)
        precision = precision_set{k};
        line(axes_precision_overlap,threshold_overlap,precision,'color',color_list{k},'LineStyle','-','LineWidth',2,'marker',marker_list{k});
        xlabel('�غ϶���ֵ');
        ylabel('֡��/��֡��');
        hold on;
    end
    legend('IKCF','KCF','CSK','MOSSE','MEANSHIFT','Location','northwest');
   

end