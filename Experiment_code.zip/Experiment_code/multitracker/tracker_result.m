function varargout = tracker_result(varargin)
% TRACKER_RESULT MATLAB code for tracker_result.fig
%      TRACKER_RESULT, by itself, creates a new TRACKER_RESULT or raises the existing
%      singleton*.
%
%      H = TRACKER_RESULT returns the handle to a new TRACKER_RESULT or the handle to
%      the existing singleton*.
%
%      TRACKER_RESULT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TRACKER_RESULT.M with the given input arguments.
%
%      TRACKER_RESULT('Property','Value',...) creates a new TRACKER_RESULT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before tracker_result_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to tracker_result_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help tracker_result

% Last Modified by GUIDE v2.5 25-May-2018 18:47:22

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @tracker_result_OpeningFcn, ...
                   'gui_OutputFcn',  @tracker_result_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before tracker_result is made visible.
function tracker_result_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to tracker_result (see VARARGIN)

% Choose default command line output for tracker_result
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes tracker_result wait for user response (see UIRESUME)
% uiwait(handles.figure_main);


% --- Outputs from this function are returned to the command line.
function varargout = tracker_result_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



% --- Executes on button press in pushbutton_meanshift.
function pushbutton_meanshift_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_meanshift (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

video_path = getappdata(handles.open_dir,'video_path');
if isempty(video_path)==0
    video_path = strcat(video_path,'\');
    display('video_path=');
    
    %���þ�ֵƯ���㷨�����㷨�õ����ٽ����
    [img_files, target_info, ground_truth] = load_video_info(video_path);
    if ~isempty(img_files)
        tracker_type = 'Meanshift';
        [tarone_positions, tartwo_positions,time] = multi_tracker(video_path, img_files, target_info, tracker_type);


        tarone_precision = precision_calculate(tarone_positions,ground_truth,1);
        tartwo_precision = precision_calculate(tartwo_positions,ground_truth,2);

        first_frame = target_info{1};
        target_sz = first_frame.tar_size;
        tarone_precision_overlap = precision_caculate_overlap(tarone_positions,ground_truth,1,target_sz{1});
        tartwo_precision_overlap = precision_caculate_overlap(tartwo_positions,ground_truth,2,target_sz{2});

        legend_name = tracker_type;
        speed = numel(img_files) /time ;
        %-------------------
        %ע�⣺1�������plot()�Ȼ�Ŀ��һ�����ߣ�hold
        %on֮������plot()��Ŀ��������ߣ�֮����set(handles,'property')����Ŀ��һ���ߵ�����ʱ�������Ŀ��һ���ߵľ��ʧЧ�������
        %��������������Ҫ����һ��ֱ���ϡ�
        %--------------------
        threshold = (1:30);

        tarone_handle = line(handles.axes_precision,threshold,tarone_precision);
        tartwo_handle = line(handles.axes_precision,threshold,tartwo_precision);

        set(tarone_handle,'LineStyle','-','LineWidth',2,'color','r','marker','s');
        set(tartwo_handle,'LineStyle','-','LineWidth',2,'color','r','marker','s');

        set(tarone_handle,'visible','off');
        set(tartwo_handle,'visible','off');

        last_tarone_handle = getappdata(hObject,'tarone_handle');
        last_tartwo_handle = getappdata(hObject,'tartwo_handle');

        if  isempty(last_tarone_handle) == 1 
            setappdata(hObject,'tarone_handle',tarone_handle);
            setappdata(hObject,'legend_name',legend_name);
            setappdata(hObject,'speed',speed);
        end
        if isempty(last_tartwo_handle) == 1
            setappdata(hObject,'tartwo_handle',tartwo_handle);
        end

        threshold_overlap = (0.02:0.02:1);
        tarone_handle_overlap = line(handles.axes_precision,threshold_overlap,tarone_precision_overlap);
        tartwo_handle_overlap = line(handles.axes_precision,threshold_overlap,tartwo_precision_overlap);
        set(tarone_handle_overlap,'LineStyle','-','LineWidth',2,'color','r','marker','s');
        set(tartwo_handle_overlap,'LineStyle','-','LineWidth',2,'color','r','marker','s'); 
        set(tarone_handle_overlap,'visible','off');
        set(tartwo_handle_overlap,'visible','off');

        last_tarone_handle_overlap = getappdata(hObject,'tarone_handle_overlap');
        last_tartwo_handle_overlap = getappdata(hObject,'tartwo_handle_overlap');

        if  isempty(last_tarone_handle_overlap) == 1 
            setappdata(hObject,'tarone_handle_overlap',tarone_handle_overlap);
            setappdata(hObject,'overlap_legend_name',legend_name);
            setappdata(hObject,'speed',speed);
        end
        if isempty(last_tartwo_handle_overlap) == 1
            setappdata(hObject,'tartwo_handle_overlap',tartwo_handle_overlap);
        end
    else
        errordlg('û����Ƶ�ɼ��أ�','����');
    end

 
else
    h=errordlg('û����Ƶ���ݣ�����ļ���','����');
    filename = './sonar.jpg';
    chgicon(h,filename);
end
% --- Executes on button press in pushbutton_Mosse.
function pushbutton_Mosse_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_Mosse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
video_path = getappdata(handles.open_dir,'video_path');
if isempty(video_path)==0
    video_path = strcat(video_path,'\');
    display('video_path=');
  
    %����KCF�����㷨�õ����ٽ����
    [img_files, target_info, ground_truth] = load_video_info(video_path);
    if ~isempty(img_files)
        tracker_type = 'Mosse';
        [tarone_positions, tartwo_positions,time] = multi_tracker(video_path, img_files, target_info, tracker_type);
        %����ground_truth����ÿһ��Ŀ��ĸ��پ��ȡ�
        %����ط�ע�⣺
        tarone_precision = precision_calculate(tarone_positions,ground_truth,1);
        tartwo_precision = precision_calculate(tartwo_positions,ground_truth,2);

        first_frame = target_info{1};
        target_sz = first_frame.tar_size;
        tarone_precision_overlap = precision_caculate_overlap(tarone_positions,ground_truth,1,target_sz{1});
        tartwo_precision_overlap = precision_caculate_overlap(tartwo_positions,ground_truth,2,target_sz{2});

        legend_name = tracker_type;
        speed = numel(img_files) /time ;
        %-------------------
        %ע�⣺1�������plot()�Ȼ�Ŀ��һ�����ߣ�hold
        %on֮������plot()��Ŀ��������ߣ�֮����set(handles,'property')����Ŀ��һ���ߵ�����ʱ�������Ŀ��һ���ߵľ��ʧЧ�������
        %��������������Ҫ����һ��ֱ���ϡ�
        %--------------------
        threshold = (1:30);
        tarone_handle = line(handles.axes_precision,threshold,tarone_precision);
        tartwo_handle = line(handles.axes_precision,threshold,tartwo_precision);
        set(tarone_handle,'LineStyle','-','LineWidth',2,'color','g','marker','>');
        set(tartwo_handle,'LineStyle','-','LineWidth',2,'color','g','marker','>');
        set(tarone_handle,'visible','off');
        set(tartwo_handle,'visible','off'); 
        last_tarone_handle = getappdata(hObject,'tarone_handle');
        last_tartwo_handle = getappdata(hObject,'tartwo_handle');
        if  isempty(last_tarone_handle) == 1 
            setappdata(hObject,'tarone_handle',tarone_handle);
            setappdata(hObject,'legend_name',legend_name);
            setappdata(hObject,'speed',speed);
        end
        if isempty(last_tartwo_handle) == 1
            setappdata(hObject,'tartwo_handle',tartwo_handle);
        end

        threshold_overlap = (0.02:0.02:1);
        tarone_handle_overlap = line(handles.axes_precision,threshold_overlap,tarone_precision_overlap);
        tartwo_handle_overlap = line(handles.axes_precision,threshold_overlap,tartwo_precision_overlap);
        set(tarone_handle_overlap,'LineStyle','-','LineWidth',2,'color','g','marker','>');
        set(tartwo_handle_overlap,'LineStyle','-','LineWidth',2,'color','g','marker','>'); 
        set(tarone_handle_overlap,'visible','off');
        set(tartwo_handle_overlap,'visible','off');

        last_tarone_handle_overlap = getappdata(hObject,'tarone_handle_overlap');
        last_tartwo_handle_overlap = getappdata(hObject,'tartwo_handle_overlap');

        if  isempty(last_tarone_handle_overlap) == 1 
            setappdata(hObject,'tarone_handle_overlap',tarone_handle_overlap);
            setappdata(hObject,'overlap_legend_name',legend_name);
            setappdata(hObject,'speed',speed);
        end
        if isempty(last_tartwo_handle_overlap) == 1
            setappdata(hObject,'tartwo_handle_overlap',tartwo_handle_overlap);
        end
    else
        errordlg('û����Ƶ���ݿɼ��أ�','����');
    end

else
    h=errordlg('û����Ƶ���ݣ�����ļ���','����');
    filename = './sonar.jpg';
    chgicon(h,filename);
end


% --- Executes on button press in pushbutton_CSK.
function pushbutton_CSK_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_CSK (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
video_path = getappdata(handles.open_dir,'video_path');
if isempty(video_path)==0
    video_path = strcat(video_path,'\');
    display('video_path=');
  
    %����KCF�����㷨�õ����ٽ����
    [img_files, target_info, ground_truth] = load_video_info(video_path);
    if ~isempty(img_files)
        tracker_type = 'CSK';
        [tarone_positions, tartwo_positions,time] = multi_tracker(video_path, img_files, target_info, tracker_type);
        %ʹ�ø��ٽ������precisiion_plot()�����õ��������ߵľ����
        %����ط�ע�⣺
        tarone_precision = precision_calculate(tarone_positions,ground_truth,1);
        tartwo_precision = precision_calculate(tartwo_positions,ground_truth,2);

        first_frame = target_info{1};
        target_sz = first_frame.tar_size;
        tarone_precision_overlap = precision_caculate_overlap(tarone_positions,ground_truth,1,target_sz{1});
        tartwo_precision_overlap = precision_caculate_overlap(tartwo_positions,ground_truth,2,target_sz{2});

        legend_name = tracker_type;
        speed = numel(img_files) /time ;
        %-------------------
        %ע�⣺1�������plot()�Ȼ�Ŀ��һ�����ߣ�hold
        %on֮������plot()��Ŀ��������ߣ�֮����set(handles,'property')����Ŀ��һ���ߵ�����ʱ�������Ŀ��һ���ߵľ��ʧЧ�������
        %��������������Ҫ����һ��ֱ���ϡ�
        %--------------------
        threshold = (1:30);
        tarone_handle = line(handles.axes_precision,threshold,tarone_precision);
        tartwo_handle = line(handles.axes_precision,threshold,tartwo_precision);
        set(tarone_handle,'LineStyle','-','LineWidth',2,'color','b','marker','*');
        set(tartwo_handle,'LineStyle','-','LineWidth',2,'color','b','marker','*');
        set(tarone_handle,'visible','off');
        set(tartwo_handle,'visible','off');
        last_tarone_handle = getappdata(hObject,'tarone_handle');
        last_tartwo_handle = getappdata(hObject,'tartwo_handle');
        if  isempty(last_tarone_handle) == 1 
            setappdata(hObject,'tarone_handle',tarone_handle);
            setappdata(hObject,'legend_name',legend_name);
            setappdata(hObject,'speed',speed);
        end
        if isempty(last_tartwo_handle) == 1
            setappdata(hObject,'tartwo_handle',tartwo_handle);
        end


        threshold_overlap = (0.02:0.02:1);
        tarone_handle_overlap = line(handles.axes_precision,threshold_overlap,tarone_precision_overlap);
        tartwo_handle_overlap = line(handles.axes_precision,threshold_overlap,tartwo_precision_overlap);
        set(tarone_handle_overlap,'LineStyle','-','LineWidth',2,'color','b','marker','*');
        set(tartwo_handle_overlap,'LineStyle','-','LineWidth',2,'color','b','marker','*'); 
        set(tarone_handle_overlap,'visible','off');
        set(tartwo_handle_overlap,'visible','off');

        last_tarone_handle_overlap = getappdata(hObject,'tarone_handle_overlap');
        last_tartwo_handle_overlap = getappdata(hObject,'tartwo_handle_overlap');

        if  isempty(last_tarone_handle_overlap) == 1 
            setappdata(hObject,'tarone_handle_overlap',tarone_handle_overlap);
            setappdata(hObject,'overlap_legend_name',legend_name);
            setappdata(hObject,'speed',speed);
        end
        if isempty(last_tartwo_handle_overlap) == 1
            setappdata(hObject,'tartwo_handle_overlap',tartwo_handle_overlap);
        end
    else
        errordlg('û����Ƶ���ݿɼ��أ�','����');
    end


else
    h=errordlg('û����Ƶ���ݣ�����ļ���','����');
    filename = './sonar.jpg';
    chgicon(h,filename);
end

% --- Executes on button press in pushbutton_correlation.
function pushbutton_correlation_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_correlation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%���ܣ����û����º�����˲��㷨�������ʱ�򣬵���multi_tracker()������
% 
video_path = getappdata(handles.open_dir,'video_path');
if isempty(video_path)==0
    video_path = strcat(video_path,'\');
    display('video_path=');
  
    %����KCF�����㷨�õ����ٽ����
    [img_files, target_info, ground_truth] = load_video_info(video_path);
    if ~isempty(img_files)
        tracker_type = 'KCF';
        [tarone_positions, tartwo_positions,time] = multi_tracker(video_path, img_files, target_info, tracker_type);
        %ʹ�ø��ٽ������precisiion_plot()�����õ��������ߵľ����
        %����ط�ע�⣺
        tarone_precision = precision_calculate(tarone_positions,ground_truth,1);
        tartwo_precision = precision_calculate(tartwo_positions,ground_truth,2);

        first_frame = target_info{1};
        target_sz = first_frame.tar_size;
        tarone_precision_overlap = precision_caculate_overlap(tarone_positions,ground_truth,1,target_sz{1});
        tartwo_precision_overlap = precision_caculate_overlap(tartwo_positions,ground_truth,2,target_sz{2});

        legend_name = tracker_type;
        speed = numel(img_files) /time ;
        %-------------------
        %ע�⣺1�������plot()�Ȼ�Ŀ��һ�����ߣ�hold
        %on֮������plot()��Ŀ��������ߣ�֮����set(handles,'property')����Ŀ��һ���ߵ�����ʱ�������Ŀ��һ���ߵľ��ʧЧ�������
        %��������������Ҫ����һ��ֱ���ϡ�
        %--------------------
        threshold = (1:30);
        tarone_handle = line(handles.axes_precision,threshold,tarone_precision);
        tartwo_handle = line(handles.axes_precision,threshold,tartwo_precision); 
        set(tarone_handle,'LineStyle','-','LineWidth',2,'color','c','marker','d');
        set(tartwo_handle,'LineStyle','-','LineWidth',2,'color','c','marker','d');
        set(tarone_handle,'visible','off');
        set(tartwo_handle,'visible','off');    
        last_tarone_handle = getappdata(hObject,'tarone_handle');
        last_tartwo_handle = getappdata(hObject,'tartwo_handle');
        if  isempty(last_tarone_handle) == 1 
            setappdata(hObject,'tarone_handle',tarone_handle);
            setappdata(hObject,'legend_name',legend_name);
            setappdata(hObject,'speed',speed);
        end
        if isempty(last_tartwo_handle) == 1
            setappdata(hObject,'tartwo_handle',tartwo_handle);
        end

        threshold_overlap = (0.02:0.02:1);
        tarone_handle_overlap = line(handles.axes_precision,threshold_overlap,tarone_precision_overlap);
        tartwo_handle_overlap = line(handles.axes_precision,threshold_overlap,tartwo_precision_overlap);
        set(tarone_handle_overlap,'LineStyle','-','LineWidth',2,'color','c','marker','d');
        set(tartwo_handle_overlap,'LineStyle','-','LineWidth',2,'color','c','marker','d'); 
        set(tarone_handle_overlap,'visible','off');
        set(tartwo_handle_overlap,'visible','off');
        last_tarone_handle_overlap = getappdata(hObject,'tarone_handle_overlap');
        last_tartwo_handle_overlap = getappdata(hObject,'tartwo_handle_overlap');

        if  isempty(last_tarone_handle_overlap) == 1 
            setappdata(hObject,'tarone_handle_overlap',tarone_handle_overlap);
            setappdata(hObject,'overlap_legend_name',legend_name);
            setappdata(hObject,'speed',speed);
        end
        if isempty(last_tartwo_handle_overlap) == 1
            setappdata(hObject,'tartwo_handle_overlap',tartwo_handle_overlap);
        end
    else
        errordlg('û����Ƶ���ݿɼ��أ�','����');
    end
   
   
else
    h=errordlg('û����Ƶ���ݣ�����ļ���','����');
    filename = './sonar.jpg';
    chgicon(h,filename);
end

% --- Executes on button press in pushbutton_correlation_advanced.
function pushbutton_correlation_advanced_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton_correlation_advanced (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
video_path = getappdata(handles.open_dir,'video_path');
if isempty(video_path)==0
    video_path = strcat(video_path,'\');
    display('video_path=');
  
    %����KCF�����㷨�õ����ٽ����
    [img_files, target_info, ground_truth] = load_video_info(video_path);
    if ~isempty(img_files)
        tracker_type = 'improved_KCF';
        [tarone_positions, tartwo_positions,time] = multi_tracker(video_path, img_files, target_info, tracker_type);
        %ʹ�ø��ٽ������precisiion_plot()�����õ��������ߵľ����
        %����ط�ע�⣺
        tarone_precision = precision_calculate(tarone_positions,ground_truth,1);
        tartwo_precision = precision_calculate(tartwo_positions,ground_truth,2);

        first_frame = target_info{1};
        target_sz = first_frame.tar_size;
        tarone_precision_overlap = precision_caculate_overlap(tarone_positions,ground_truth,1,target_sz{1});
        tartwo_precision_overlap = precision_caculate_overlap(tartwo_positions,ground_truth,2,target_sz{2});

        legend_name = tracker_type;
        speed = numel(img_files) /time ;

        threshold = (1:30);
        tarone_handle = line(handles.axes_precision,threshold,tarone_precision);
        tartwo_handle = line(handles.axes_precision,threshold,tartwo_precision);
        set(tarone_handle,'LineStyle','-','LineWidth',2,'color','m','marker','^');
        set(tartwo_handle,'LineStyle','-','LineWidth',2,'color','m','marker','^');
        set(tarone_handle,'visible','off');
        set(tartwo_handle,'visible','off');
        last_tarone_handle = getappdata(hObject,'tarone_handle');
        last_tartwo_handle = getappdata(hObject,'tartwo_handle');
        if  isempty(last_tarone_handle) == 1 
            setappdata(hObject,'tarone_handle',tarone_handle);
            setappdata(hObject,'legend_name',legend_name);
            setappdata(hObject,'speed',speed);
        end
        if isempty(last_tartwo_handle) == 1
            setappdata(hObject,'tartwo_handle',tartwo_handle);
        end

        threshold_overlap = (0.02:0.02:1);
        tarone_handle_overlap = line(handles.axes_precision,threshold_overlap,tarone_precision_overlap);
        tartwo_handle_overlap = line(handles.axes_precision,threshold_overlap,tartwo_precision_overlap);
        set(tarone_handle_overlap,'LineStyle','-','LineWidth',2,'color','m','marker','^');
        set(tartwo_handle_overlap,'LineStyle','-','LineWidth',2,'color','m','marker','^'); 
        set(tarone_handle_overlap,'visible','off');
        set(tartwo_handle_overlap,'visible','off');

        last_tarone_handle_overlap = getappdata(hObject,'tarone_handle_overlap');
        last_tartwo_handle_overlap = getappdata(hObject,'tartwo_handle_overlap');

        if  isempty(last_tarone_handle_overlap) == 1 
            setappdata(hObject,'tarone_handle_overlap',tarone_handle_overlap);
            setappdata(hObject,'overlap_legend_name',legend_name);
            setappdata(hObject,'speed',speed);
        end
        if isempty(last_tartwo_handle_overlap) == 1
            setappdata(hObject,'tartwo_handle_overlap',tartwo_handle_overlap);
        end
    else
        errordlg('û����Ƶ���ݿɼ��أ�','����');
    end

else
    h=errordlg('û����Ƶ���ݣ�����ļ���','����');
    filename = './sonar.jpg';
    chgicon(h,filename);
end



% --- Executes during object creation, after setting all properties.
function figure_main_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure_main (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
filename = './sonar.jpg';
chgicon(hObject,filename);


%��buttonGoup ���ѡ��������ı�ʱִ�д˺�����
%�˺����Ĺ��ܣ�
%1����ȡĿ��һ�ĸ��㷨��Ӧ�ľ�������tarone_line_handle��ͼ������legend_name�������ٶ�Fps;
% --- Executes when selected object is changed in uibuttongroup_targetchoose.
function uibuttongroup_targetchoose_SelectionChangedFcn(hObject, eventdata, handles)
% hObject    handle to the selected object in uibuttongroup_targetchoose 
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

one_legends = {};
two_legends = {};
one_handles = [];
two_handles = [];
speed = [];


mean_tarone_handle = getappdata(handles.pushbutton_meanshift,'tarone_handle');
mean_tartwo_handle = getappdata(handles.pushbutton_meanshift,'tartwo_handle');
mean_legend_name = getappdata(handles.pushbutton_meanshift,'legend_name');
mean_speed = getappdata(handles.pushbutton_meanshift,'speed');

if isempty(mean_tarone_handle) == 0
    one_handles(end+1) = mean_tarone_handle;
    one_legends{end + 1} = mean_legend_name;
    speed(end+1) = mean_speed;

end
if isempty(mean_tartwo_handle) == 0
    two_handles(end + 1) = mean_tartwo_handle;
    two_legends{end + 1} = mean_legend_name;
end

mosse_tarone_handle = getappdata(handles.pushbutton_Mosse,'tarone_handle');
mosse_tartwo_handle = getappdata(handles.pushbutton_Mosse,'tartwo_handle');
mosse_legend_name = getappdata(handles.pushbutton_Mosse,'legend_name');
mosse_speed = getappdata(handles.pushbutton_Mosse,'speed');

if isempty(mosse_tarone_handle) == 0
    one_handles(end+1) = mosse_tarone_handle;
    one_legends{end + 1} = mosse_legend_name;
    speed(end+1) = mosse_speed;

end
if isempty(mosse_tartwo_handle) == 0
    two_handles(end + 1) = mosse_tartwo_handle;
    two_legends{end + 1} = mosse_legend_name;
end

csk_tarone_handle = getappdata(handles.pushbutton_CSK,'tarone_handle');
csk_tartwo_handle = getappdata(handles.pushbutton_CSK,'tartwo_handle');
csk_legend_name = getappdata(handles.pushbutton_CSK,'legend_name');
csk_speed = getappdata(handles.pushbutton_CSK,'speed');

if isempty(csk_tarone_handle) == 0
    one_handles(end+1) = csk_tarone_handle;
    one_legends{end + 1} = csk_legend_name;
    speed(end+1) = csk_speed;

end
if isempty(csk_tartwo_handle) == 0
    two_handles(end + 1) = csk_tartwo_handle;
    two_legends{end + 1} = csk_legend_name;
end



kcf_tarone_handle = getappdata(handles.pushbutton_correlation,'tarone_handle');
kcf_tartwo_handle = getappdata(handles.pushbutton_correlation,'tartwo_handle');
kcf_legend_name = getappdata(handles.pushbutton_correlation,'legend_name');
kcf_speed = getappdata(handles.pushbutton_correlation,'speed');

if isempty(kcf_tarone_handle) == 0
    one_handles(end+1) = kcf_tarone_handle;
    one_legends{end + 1} = kcf_legend_name;
    speed(end+1) = kcf_speed;


end
if isempty(kcf_tartwo_handle) == 0
    two_handles(end + 1) = kcf_tartwo_handle;
    two_legends{end + 1} = kcf_legend_name;
end

advancekcf_tarone_handle = getappdata(handles.pushbutton_correlation_advanced,'tarone_handle');
advancekcf_tartwo_handle = getappdata(handles.pushbutton_correlation_advanced,'tartwo_handle');
advancekcf_legend_name = getappdata(handles.pushbutton_correlation_advanced,'legend_name');
advancekcf_speed = getappdata(handles.pushbutton_correlation_advanced,'speed');

if isempty(advancekcf_tarone_handle) == 0
    one_handles(end+1) = advancekcf_tarone_handle;
    one_legends{end + 1} = advancekcf_legend_name;
    speed(end +1) = advancekcf_speed;

end
if isempty(advancekcf_tartwo_handle) == 0
    two_handles(end + 1) = advancekcf_tartwo_handle;
    two_legends{end + 1} = advancekcf_legend_name;
end

overlapone_legends = {};
overlaptwo_legends = {};
overlap_one_handles = [];
overlap_two_handles = [];
overlap_speed = [];

overlap_mean_tarone_handle = getappdata(handles.pushbutton_meanshift,'tarone_handle_overlap');
overlap_mean_tartwo_handle = getappdata(handles.pushbutton_meanshift,'tartwo_handle_overlap');
overlap_mean_legend_name = getappdata(handles.pushbutton_meanshift,'overlap_legend_name');
overlap_mean_speed = getappdata(handles.pushbutton_meanshift,'speed');

if isempty(overlap_mean_tarone_handle) == 0
    overlap_one_handles(end+1) = overlap_mean_tarone_handle;
    overlapone_legends{end + 1} = overlap_mean_legend_name;
    overlap_speed(end+1) = overlap_mean_speed;

end
if isempty(overlap_mean_tartwo_handle) == 0
    overlap_two_handles(end + 1) = overlap_mean_tartwo_handle;
    overlaptwo_legends{end + 1} = overlap_mean_legend_name;
end

overlap_mosse_tarone_handle = getappdata(handles.pushbutton_Mosse,'tarone_handle_overlap');
overlap_mosse_tartwo_handle = getappdata(handles.pushbutton_Mosse,'tartwo_handle_overlap');
overlap_mosse_legend_name = getappdata(handles.pushbutton_Mosse,'overlap_legend_name');
overlap_mosse_speed = getappdata(handles.pushbutton_Mosse,'speed');

if isempty(overlap_mosse_tarone_handle) == 0
    overlap_one_handles(end+1) = overlap_mosse_tarone_handle;
    overlapone_legends{end + 1} = overlap_mosse_legend_name;
    overlap_speed(end+1) = overlap_mosse_speed;

end
if isempty(overlap_mosse_tartwo_handle) == 0
    overlap_two_handles(end + 1) = overlap_mosse_tartwo_handle;
    overlaptwo_legends{end + 1} = overlap_mosse_legend_name;
end

overlap_csk_tarone_handle = getappdata(handles.pushbutton_CSK,'tarone_handle_overlap');
overlap_csk_tartwo_handle = getappdata(handles.pushbutton_CSK,'tartwo_handle_overlap');
overlap_csk_legend_name = getappdata(handles.pushbutton_CSK,'overlap_legend_name');
overlap_csk_speed = getappdata(handles.pushbutton_CSK,'speed');

if isempty(overlap_csk_tarone_handle) == 0
    overlap_one_handles(end+1) = overlap_csk_tarone_handle;
    overlapone_legends{end + 1} = overlap_csk_legend_name;
    overlap_speed(end+1) = overlap_csk_speed;

end
if isempty(overlap_csk_tartwo_handle) == 0
    overlap_two_handles(end + 1) = overlap_csk_tartwo_handle;
    overlaptwo_legends{end + 1} = overlap_csk_legend_name;
end



overlap_kcf_tarone_handle = getappdata(handles.pushbutton_correlation,'tarone_handle_overlap');
overlap_kcf_tartwo_handle = getappdata(handles.pushbutton_correlation,'tartwo_handle_overlap');
overlap_kcf_legend_name = getappdata(handles.pushbutton_correlation,'overlap_legend_name');
overlap_kcf_speed = getappdata(handles.pushbutton_correlation,'speed');

if isempty(overlap_kcf_tarone_handle) == 0
    overlap_one_handles(end+1) = overlap_kcf_tarone_handle;
    overlapone_legends{end + 1} = overlap_kcf_legend_name;
    overlap_speed(end+1) = overlap_kcf_speed;


end
if isempty(overlap_kcf_tartwo_handle) == 0
    overlap_two_handles(end + 1) = overlap_kcf_tartwo_handle;
    overlaptwo_legends{end + 1} = overlap_kcf_legend_name;
end

overlap_advancekcf_tarone_handle = getappdata(handles.pushbutton_correlation_advanced,'tarone_handle_overlap');
overlap_advancekcf_tartwo_handle = getappdata(handles.pushbutton_correlation_advanced,'tartwo_handle_overlap');
overlap_advancekcf_legend_name = getappdata(handles.pushbutton_correlation_advanced,'overlap_legend_name');
overlap_advancekcf_speed = getappdata(handles.pushbutton_correlation_advanced,'speed');

if isempty(overlap_advancekcf_tarone_handle) == 0
    overlap_one_handles(end+1) = overlap_advancekcf_tarone_handle;
    overlapone_legends{end + 1} = overlap_advancekcf_legend_name;
    overlap_speed(end +1) = overlap_advancekcf_speed;

end
if isempty(overlap_advancekcf_tartwo_handle) == 0
    overlap_two_handles(end + 1) = overlap_advancekcf_tartwo_handle;
    overlaptwo_legends{end + 1} = overlap_advancekcf_legend_name;
end
    

%�Ծ�����㾫�ȵ�barͼ
% ����ٶ�����speed��Ԫ�ز���5������0��䡣
% ����barͼ��x�������label
bar_x_label = one_legends;
for i = 1:5- size(speed,2)
    speed(end +1) = 0;
    bar_x_label{end + 1} = '';
end
%���ص��ȼ��㾫�ȵ�barͼ
overlap_bar_x_label = overlapone_legends;
for i = 1:5- size(overlap_speed,2)
    overlap_speed(end +1) = 0;
    overlap_bar_x_label{end + 1} = '';
end

popmenu_choice = get(handles.popupmenu_precision_cacultate,'Value');

%���ٶ���״ͼ
if popmenu_choice == 1
    bar(handles.axes_speed,speed);
    if numel(speed)==5
        display('speed=');
        speed
    end
    set(handles.axes_speed,'xticklabel',bar_x_label);
else
    bar(handles.axes_speed,overlap_speed);
    set(handles.axes_speed,'xticklabel',overlap_bar_x_label);
    
end 

selected_target = get(hObject,'tag');
switch selected_target
    case 'radiobutton_targetone'
        if popmenu_choice == 1
%             set(handles.text_threshold,'String','����λ�����');
            xlabel(handles.axes_precision,'����λ�������ֵ','FontWeight','bold');
            set(handles.axes_precision,'XLim',[1,30]);
            set(one_handles,'visible','on');
            set(two_handles,'visible','off');
            set(overlap_one_handles,'visible','off');
            set(overlap_two_handles,'visible','off');
            legend(handles.axes_precision,one_handles,one_legends,'Location','northwest');
        else
%             set(handles.text_threshold,'String','����غ϶�');
            xlabel(handles.axes_precision,'����غ϶���ֵ','FontWeight','bold');
            set(handles.axes_precision,'XLim',[0.02,1]);
            set(overlap_one_handles,'visible','on');
            set(overlap_two_handles,'visible','off');
            set(one_handles,'visible','off');
            set(two_handles,'visible','off')
            legend(handles.axes_precision,overlap_one_handles,overlapone_legends,'Location','northeast');
        end
    case 'radiobutton_targettwo'
        
        if popmenu_choice == 1
%             set(handles.text_threshold,'String','����λ�����');
            xlabel(handles.axes_precision,'����λ�������ֵ','FontWeight','bold');
            set(handles.axes_precision,'XLim',[1,30]);
            set(two_handles,'visible','on');
            set(one_handles,'visible','off');
            set(overlap_one_handles,'visible','off');
            set(overlap_two_handles,'visible','off');
            legend(handles.axes_precision,two_handles,two_legends,'Location','northwest');
        else
%             set(handles.text_threshold,'String','����غ϶�');
            xlabel(handles.axes_precision,'����غ϶���ֵ','FontWeight','bold');
            set(handles.axes_precision,'XLim',[0.02,1]);
            set(overlap_two_handles,'visible','on');
            set(overlap_one_handles,'visible','off');
            set(two_handles,'visible','off');
            set(one_handles,'visible','off');
            overlaptwo_legends
            legend(handles.axes_precision,overlap_two_handles,overlaptwo_legends,'Location','northeast');
        end
            
end
        




% --------------------------------------------------------------------

%�˵����򿪲˵���
% --------------------------------------------------------------------
function open_dir_Callback(hObject, eventdata, handles)
% hObject    handle to open_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
directory_name=uigetdir();
setappdata(hObject,'video_path',directory_name);


%���������ļ����ߡ�
% --------------------------------------------------------------------
function uipushtool_open_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to uipushtool_open (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
directory_name=uigetdir();
setappdata(hObject,'video_path',directory_name);




% --- Executes during object creation, after setting all properties.
function radiobutton_targettwo_CreateFcn(hObject, eventdata, handles)
% hObject    handle to radiobutton_targettwo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
set(hObject,'value',0);

function radiobutton_targetone_CreateFcn(hObject, eventdata, handles)
% hObject    handle to radiobutton_targettwo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
set(hObject,'value',0);


% --- Executes on selection change in popupmenu_precision_cacultate.
function popupmenu_precision_cacultate_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu_precision_cacultate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu_precision_cacultate contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu_precision_cacultate


% --- Executes during object creation, after setting all properties.
function popupmenu_precision_cacultate_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu_precision_cacultate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function text_precision_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text_precision (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function axes_precision_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes_precision (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
% Hint: place code in OpeningFcn to populate axes_precision
xlabel(hObject,'����λ�������ֵ','FontWeight','bold');
ylabel(hObject,'֡��/��֡��','FontWeight','bold');
