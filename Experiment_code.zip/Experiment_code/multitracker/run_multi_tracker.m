function [precision, fps]=run_multi_tracker()
    video_path = uigetdir();
    video_path = strcat(video_path,'\');
    
     %����load_video_info(video_path)�õ�Ŀ�����ʵλ����Ϣground_truth
    [img_files, target_info, ground_truth] = load_video_info(video_path);
    tracker_type = 'KCF';
    [one ,two ,time] = multi_tracker(video_path, img_files, target_info,tracker_type);

end