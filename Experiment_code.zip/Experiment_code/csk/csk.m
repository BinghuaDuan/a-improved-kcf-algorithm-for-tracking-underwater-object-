%--------------------------------------------------------------------------
%time: 2018/5/8 15:29
%���ܣ���ѭ���ܼ�����������Ϊѵ��������ѵ���˲���
%�޸�ʱ�䣺
%�޸����ݣ�������paddingde
function [positions,show_box] = csk(video_path, img_files, pos, target_sz)


%CSK����
padding = 1;					%��������
output_sigma_factor = 1/16;		%��ǩ�ĸ�˹�ֲ�
sigma = 0.2;					%��˹�˴���
lambda = 1e-2;					%����ϵ��
interp_factor = 0.075;			%ģ�͸��µ����Բ�ֵϵ��


%window�ĳߴ�
window_sz = floor(target_sz * (1 + padding));

%��ǩ�ʸ�˹�ֲ�
output_sigma = sqrt(prod(target_sz)) * output_sigma_factor;
[rs, cs] = ndgrid((1:window_sz(1)) - floor(window_sz(1)/2), (1:window_sz(2)) - floor(window_sz(2)/2));
y = exp(-0.5 / output_sigma^2 * (rs.^2 + cs.^2));
yf = fft2(y);

%�洢���ȼ�������Ҵ�
cos_window = hann(window_sz(1)) * hann(window_sz(2))';



positions = zeros(numel(img_files), 2);  %to calculate precision
rects = cell(numel(img_files), 1);

% update_visualization = show_video(img_files, video_path);

for frame = 1:numel(img_files),
	
	im = imread([video_path img_files{frame}]);
	if size(im,3) > 1,
		im = rgb2gray(im);
	end
	
	%extract and pre-process subwindow
	x = get_subwindow_csk(im, pos, window_sz, cos_window);
	
	if frame > 1,
		%calculate response of the classifier at all locations
		k = dense_gauss_kernel(sigma, x, z);
		response = real(ifft2(alphaf .* fft2(k)));   %(Eq. 9)
		
		%target location is at the maximum response
		[row, col] = find(response == max(response(:)), 1);
		pos = pos - floor(window_sz/2) + [row, col];
	end
	
	%get subwindow at current estimated target position, to train classifer
	x = get_subwindow_csk(im, pos, window_sz, cos_window);
	
	%Kernel Regularized Least-Squares, calculate alphas (in Fourier domain)
	k = dense_gauss_kernel(sigma, x);
	new_alphaf = yf ./ (fft2(k) + lambda);   %(Eq. 7)
	new_z = x;
	
	if frame == 1,  %first frame, train with a single image
		alphaf = new_alphaf;
		z = x;
	else
		%subsequent frames, interpolate model
		alphaf = (1 - interp_factor) * alphaf + interp_factor * new_alphaf;
		z = (1 - interp_factor) * z + interp_factor * new_z;
	end
	
	%save position and calculate FPS
	positions(frame,:) = pos;
    box = [pos([2,1]) - floor(target_sz([2,1]) /2),target_sz([2,1])];
    rects{frame} = box;
%     update_visualization(frame, {box});
    
	
% 	%visualization
% 	rect_position = [pos([2,1]) - target_sz([2,1])/2, target_sz([2,1])];
% 	if frame == 1,  %first frame, create GUI
% % 		figure('Number','off', 'Name',['Tracker - ' video_path])
% 		im_handle = imshow(im, 'Border','tight', 'InitialMag',200);
% 		rect_handle = rectangle('Position',rect_position, 'EdgeColor','r','LineWidth',2);
% 	else
% 		try  %subsequent frames, update GUI
% 			set(im_handle, 'CData', im)
% 			set(rect_handle, 'Position', rect_position)
% 		catch  %#ok, user has closed the window
% 			return
% 		end
% 	end
	
% 	drawnow
% 	pause(0.05)  %uncomment to run slower
end
show_box = rects;

% 
% disp(['Frames-per-second: ' num2str(numel(img_files) / time)])


end